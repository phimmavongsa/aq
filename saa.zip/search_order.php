<?php include('session.php'); ?>
<?php include 'public/headtop.php'; ?>
<?php include 'public/head.php'; ?>
<?php include 'public/search_order.php'; ?>
<?php include 'public/calculator.php'; ?>
<?php include 'public/footer-top.php'; ?>
<?php include 'public/footer-bottom.php'; ?>
<?php include 'public/scroll-to-top.php'; ?>