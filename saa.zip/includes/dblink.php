<?php
$con=mysqli_connect("localhost","root","sql@2019","apis_wast");
mysqli_set_charset($con,"utf8");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
date_default_timezone_set("Asia/Vientiane");
if(isset($_GET)){
	foreach ($_GET as $key => $value) {
  $_GET[$key]=addslashes(strip_tags(trim($value)));
}
	   
extract($_GET);

}else{
		
	foreach ($_POST as $key => $value) {
  $_POST[$key]=addslashes(strip_tags(trim($value)));
}
	   
extract($_POST); 	
}
?>