<?php 
	$host = "localhost";
    $user = "u6bfq5ndvh9mf";
    $pass = "17*11}diF;1b";
    $database = "dbdhr8up7rz3jh";

    $connect = new mysqli($host, $user, $pass, $database);

    if (!$connect) {
        die ("connection failed: " . mysqli_connect_error());
		
    } else {
        $connect->set_charset('utf8');
    }
	
	$GLOBALS['config'] = $connect;

    $ENABLE_RTL_MODE = 'false';
?>