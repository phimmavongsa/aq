    <!-- App Bottom Menu -->
    <div class="appBottomMenu bg-primary text-light">
        <a href="register.php" class="item">
            <div class="col">
                <ion-icon name="person-add-outline"></ion-icon>
                <strong>ລົງທະບຽນ</strong>
            </div>
        </a>
        <a href="login.php" class="item active">
            <div class="col">
             <ion-icon name="log-in-outline"></ion-icon>
                <strong>ເຂົ້າລະບົບ</strong>
            </div>
        </a> 
        <a href="blog.php" class="item">
            <div class="col">
                <ion-icon name="list-circle-outline"></ion-icon>
                <strong>ຂ່າວສານ</strong>
            </div>
        </a> 		
    </div>	
    <!-- * App Bottom Menu -->	
