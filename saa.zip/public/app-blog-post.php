
    <!-- App Header -->
  <div class="appHeader bg-primary text-light">
        <div class="left">
            <a href="#" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">
            ເນື້ອໃນຂ່າວສານ
        </div>
        <div class="right">
            <a href="javascript:;" class="headerButton" data-toggle="modal" data-target="#actionSheetShare">
                <ion-icon name="share-social-outline"></ion-icon>
            </a>
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">


        <div class="section mt-2">
            <h1>
                ບໍລິການທຸລະກຳດ້ານການເງິນ
            </h1>
            <div class="blog-header-info mt-2 mb-2">
                <div>
                    <img src="assets/img/sample/avatar/avatar1.jpg" alt="img" class="imaged w24 rounded mr-05">
                    ສະເໜີໂດຍ: <a href="#">admin</a>
                </div>
                <div>
                    24, September 2021
                </div>
            </div>
            <div class="lead">
                ສະຖານບັນການເງິນຊັບທະວີບໍລິການແລກປ່ຽນເງິນຕາ, ໃຫ້ບໍລິການສິນເຊື່ອ ແລະ ຂາຍປະກັນໄພ.
            </div>
        </div>

        <div class="section mt-2">
            <p>
                ບໍລິການແລກປ່ຽນເງິນຕາຕ່າງປະເທດ ຫລາຍສະກຸນເງິນ
            </p>
            <figure>
                <img src="assets/img/news/photo/11.jpg" alt="image" class="imaged img-fluid">
            </figure>
            
            <figure>
                <img src="assets/img/news/photo/66.jpg" alt="image" class="imaged img-fluid">
            </figure>
            <h3>ບໍລິການຂາຍປະກັນໄພ</h3>
              <p>
                ບໍລິການຂາຍປະກັນໄພ            
        </div>

        <div class="section">
            <a href="#" class="btn btn-block btn-primary" data-toggle="modal" data-target="#actionSheetShare">
                <ion-icon name="share-outline"></ion-icon> ແບ່ງປັນຂ່ານນີ້ (Share this post)
            </a>
        </div>


        <div class="section mt-3">
            <h2>ຂ່າວທີ່ພົວພັນ</h2>
            <div class="row mt-3">
                <div class="col-6 mb-2">
                    <a href="blog-post.php">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/11.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ບໍລິການທຸລະກຳດ້ານການເງິນ</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-6 mb-2">
                    <a href="blog-post.php">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/22.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ສິນເຊື່ອເງິນດ່ວນ</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-6 mb-2">
                    <a href="blog-post.php">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/33.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ບໍລິການຖອນເງິນສົດ EDC</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-6 mb-2">
                    <a href="blog-post.php">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/44.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ບໍລິການຊຳລະຄ່າໄຟຟ້າ, ນ້ຳປະປາ</h4>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>


    </div>
    <!-- * App Capsule -->

    <!-- Share Action Sheet -->
    <div class="modal fade action-sheet inset" id="actionSheetShare" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">ແບ່ງປັນຂ່າວ(Share with)</h5>
                </div>
                <div class="modal-body">
                    <ul class="action-button-list">
                        <li>
                            <a href="#" class="btn btn-list" data-dismiss="modal">
                                <span>
                                    <ion-icon name="logo-facebook"></ion-icon>
                                    Facebook
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="btn btn-list" data-dismiss="modal">
                                <span>
                                    <ion-icon name="logo-twitter"></ion-icon>
                                    Twitter
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="btn btn-list" data-dismiss="modal">
                                <span>
                                    <ion-icon name="logo-instagram"></ion-icon>
                                    Instagram
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="btn btn-list" data-dismiss="modal">
                                <span>
                                    <ion-icon name="logo-linkedin"></ion-icon>
                                    Linkedin
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- * Share Action Sheet -->

