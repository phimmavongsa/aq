
    <!-- App Header -->
  <div class="appHeader bg-primary text-light">
        <div class="left">
            <a href="#" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">
            ເນື້ອໃນຂໍ້ຄວາມ
        </div>
        <div class="right">
            <a href="javascript:;" class="headerButton">
                <ion-icon name="trash-outline"></ion-icon>
            </a>
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="section">

            <div class="listed-detail mt-3">
                <div class="icon-wrapper">
                    <div class="iconbox">
                        <ion-icon name="arrow-down-outline"></ion-icon>
                    </div>
                </div>
                <h3 class="text-center mt-2">ການຊຳລະເງິນຂອງທ່ານສຳເລັດ</h3>
            </div>

            <ul class="listview simple-listview no-space mt-3">
                <li>
                    <span>ຈາກ</span>
                    <strong>ທ່ານ ໝອນ</strong>
                </li>
                <li>
                    <span>ຊື່ບັນຊີທະນາຄານ</span>
                    <strong>ຈັນສະໝອນ</strong>
                </li>
                <li>
                    <span>ວັນທີ</span>
                    <strong>Sep 25, 2020 10:45 AM</strong>
                </li>
                <li>
                    <span>ຈຳນວນ</span>
                    <strong>₭ 50</strong>
                </li>
            </ul>


        </div>

    </div>
    <!-- * App Capsule -->