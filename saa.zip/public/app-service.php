		
		<!-- App Capsule -->
    <div id="appCapsule">

        <div class="carousel-slider owl-carousel owl-theme">
            <div class="item p-2">         
                <img src="../assets/img/service/avatar1.jpg" alt="alt"  height="64" width="64" class="imaged w-100 square mb-4">
             <h2>Minimalist and Stylish</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>

            </div>
            <div class="item p-2">
                <img src="../assets/img/service/avatar1.jpg" alt="alt"  height="64" width="64" class="imaged w-100 square mb-4">
                <h2>Minimalist and Stylish</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
            <div class="item p-2">
                <img src="../assets/img/service/avatar1.jpg" alt="alt"  height="64" width="64" class="imaged w-100 square mb-4">
                <h2>Easy to Use Components</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
			 <div class="item p-2">
                <img src="../assets/img/service/avatar1.jpg" alt="alt"  height="64" width="64" class="imaged w-100 square mb-4">
                <h2>Easy to Use Components</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
        </div>

    </div>
    <!-- * App Capsule -->
	