    <!-- App Header -->
    <div class="appHeader  bg-primary text-light no-border transparent position-absolute">
        <div class="left">
            <a href="javascript:;" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle"></div>
        <div class="right">
        </div>
		 <div class="pageTitle">
			<label style="font-size:24px;" class="label" for="photo">&nbsp;ລົງທະບຽນ</label>
        </div> 
    </div>
    <!-- * App Header -->
