    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="section mt-2 text-center">
            <h1>ເຂົ້ານຳໃຊ້ລະບົບ</h1>
            <h4>ປ້ອນຂໍ້ມູນເພື່ອເຂົ້ານຳໃຊ້ລະບົບ</h4>
        </div>
        <div class="section mb-5 p-2">

            <form action="index.php">
                <div class="card">
                    <div class="card-body pb-1">
                        <div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label" for="tel">ເບີໂທລະສັບ</label>														
									
                                <input type="tel" class="form-control" id="userid" name="userid" pattern="[0-9]{2}[0-9]{8}" placeholder="ເບີໂທລະສັບ">                        
                                <i class="clear-input"><ion-icon name="close-circle"></ion-icon></i>
                            </div>						
						
                        </div>											
        
                        <div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label" for="password1">ລະຫັດຜ່ານ</label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="ລະຫັດຜ່ານ">
                                <i class="clear-input"><ion-icon name="close-circle"></ion-icon></i>
                            </div>
                        </div>
                    </div>
                </div>
				
				<div class="form-group basic transparent text-center">	
                    <button type="submit" class="btn-primary btn-block btn-lg">ເຂົ້າລະບົບ</button>
					
                </div>
				
                <div class="form-links mt-2">
                    <div><a href="register.php">ລົງທະບຽນ</a></div>
                    <div><a href="forgot-password.php" class="text-muted">ລືມລະຫັດຜ່ານ?</a></div>
                </div>

        

            </form>
        </div>

    </div>
    <!-- * App Capsule -->