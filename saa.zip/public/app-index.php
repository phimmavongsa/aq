    <!-- App Capsule -->
    <div id="appCapsule">

        <!-- Wallet Card -->
        <div class="section wallet-card-section pt-1">
            <div class="wallet-card">
                <!-- Balance -->
                <div class="balance">
                    <div class="left">
                        <span class="title">ເງິນໃນບັນຊີ</span>
                        <h1 class="total">₭ 2,562.50</h1>
                    </div>
                    <div class="right">
                        <a href="#" class="button" data-toggle="modal" data-target="#depositActionSheet">
                            <ion-icon name="add-outline"></ion-icon>
                        </a>
                    </div>
                </div>
                <!-- * Balance -->
                <!-- Wallet Footer -->
                <div class="wallet-footer">
                    <div class="item">
                        <a href="#" data-toggle="modal" data-target="#withdrawActionSheet">
                            <div class="icon-wrapper bg-danger">
                                <ion-icon name="arrow-down-outline"></ion-icon>
                            </div>
                            <strong>ຖອນເງິນ</strong>
                        </a>
                    </div>
                    <div class="item">
                        <a href="#" data-toggle="modal" data-target="#sendActionSheet">
                            <div class="icon-wrapper">
                                <ion-icon name="arrow-forward-outline"></ion-icon>
                            </div>
                            <strong>ໂອນເງິນ</strong>
                        </a>
                    </div>
                    <div class="item">
                        <a href="cards.php">
                            <div class="icon-wrapper bg-success">
                                <ion-icon name="card-outline"></ion-icon>
                            </div>
                            <strong>ເງິນໃນບັນຊີ</strong>
                        </a>
                    </div>
                    <div class="item">
                        <a href="#" data-toggle="modal" data-target="#exchangeActionSheet">
                            <div class="icon-wrapper bg-warning">
                                <ion-icon name="swap-vertical"></ion-icon>
                            </div>
                            <strong>ແລກປ່ຽນ</strong>
                        </a>
                    </div>

                </div>
                <!-- * Wallet Footer -->
            </div>
        </div>
        <!-- Wallet Card -->

        <!-- Deposit Action Sheet -->
        <div class="modal fade action-sheet" id="depositActionSheet" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">ຝາກເງິນເຂົ້າ</h5>
                    </div>
                    <div class="modal-body">
                        <div class="action-sheet-content">
                            <form>
                                <div class="form-group basic">
                                    <div class="input-wrapper">
                                        <label class="label" for="account1">ຈາກບັນຊີ</label>
                                        <select class="form-control custom-select" id="account1">
                                            <option value="0">ບັນຊີຕະຫລາດເງິນ (*** 5019)</option>
                                            <option value="1">ບັນຊີເງິນຝາກປະຢັດ (*** 6212)</option>
                                            <option value="2">ບັນຊີເງິນລາຍວັນ (*** 5021)</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group basic">
                                    <label class="label">ປ້ອນຈຳນວນເງິນ</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="input2">₭</span>
                                        </div>
                                        <input type="text" class="form-control form-control-lg" value="100">
                                    </div>
                                </div>


                                <div class="form-group basic">
                                    <button type="button" class="btn btn-primary btn-block btn-lg"
                                        data-dismiss="modal">ຝາກເງິນ</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- * Deposit Action Sheet -->

        <!-- Withdraw Action Sheet -->
        <div class="modal fade action-sheet" id="withdrawActionSheet" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">ຖອນເງິນ</h5>
                    </div>
                    <div class="modal-body">
                        <div class="action-sheet-content">
                            <form>
                                <div class="form-group basic">
                                    <div class="input-wrapper">
                                        <label class="label" for="account2d">ຈາກບັນຊີ</label>
                                        <select class="form-control custom-select" id="account2d">
											<option value="0">ບັນຊີຕະຫລາດເງິນ (*** 5019)</option>
                                            <option value="1">ບັນຊີເງິນຝາກປະຢັດ (*** 6212)</option>
                                            <option value="2">ບັນຊີເງິນລາຍວັນ (*** 5021)</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group basic">
                                    <div class="input-wrapper">
                                        <label class="label" for="text11d">ຫາບັນຊີ</label>
                                        <input type="email" class="form-control" id="text11d" placeholder="ປ້ອນເລກບັນຊີ">
                                        <i class="clear-input">
                                            <ion-icon name="close-circle"></ion-icon>
                                        </i>
                                    </div>
                                </div>

                                <div class="form-group basic">
                                    <label class="label">ຈຳນວນເງິນ</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="input14d">₭</span>
                                        </div>
                                        <input type="text" class="form-control form-control-lg" placeholder="0">
                                    </div>
                                </div>

                                <div class="form-group basic">
                                    <button type="button" class="btn btn-primary btn-block btn-lg"
                                        data-dismiss="modal">ສົ່ງຖອນ</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- * Withdraw Action Sheet -->

        <!-- Send Action Sheet -->
        <div class="modal fade action-sheet" id="sendActionSheet" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">ການໂອນເງິນ</h5>
                    </div>
                    <div class="modal-body">
                        <div class="action-sheet-content">
                            <form>
                                <div class="form-group basic">
                                    <div class="input-wrapper">
                                        <label class="label" for="account2">ຈາກບັນຊີ</label>
                                        <select class="form-control custom-select" id="account2">
                                            <option value="0">ບັນຊີຕະຫລາດເງິນ (*** 5019)</option>
                                            <option value="1">ບັນຊີເງິນຝາກປະຢັດ (*** 6212)</option>
                                            <option value="2">ບັນຊີເງິນລາຍວັນ (*** 5021)</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group basic">
                                    <div class="input-wrapper">
                                        <label class="label" for="text11">ຫາບັນຊີ</label>
                                        <input type="email" class="form-control" id="text11"
                                            placeholder="ປ້ອນເລກບັນຊີ">
                                        <i class="clear-input">
                                            <ion-icon name="close-circle"></ion-icon>
                                        </i>
                                    </div>
                                </div>

                                <div class="form-group basic">
                                    <label class="label">ຈຳນວນເງິນ</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="input14">₭</span>
                                        </div>
                                        <input type="text" class="form-control form-control-lg" placeholder="0">
                                    </div>
                                </div>

                                <div class="form-group basic">
                                    <button type="button" class="btn btn-primary btn-block btn-lg"
                                        data-dismiss="modal">ສັ່ງໂອນ</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- * Send Action Sheet -->

        <!-- Exchange Action Sheet -->
        <div class="modal fade action-sheet" id="exchangeActionSheet" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">ການແລກປ່ຽນ</h5>
                    </div>
                    <div class="modal-body">
                        <div class="action-sheet-content">
                            <form>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group basic">
                                            <div class="input-wrapper">
                                                <label class="label" for="currency1">ຈາກກຸນເງິນ</label>
                                                <select class="form-control custom-select" id="currency1">
												
                                                    <option value="1">ລາວກີບ (LAK)</option>
                                                    <option value="2">ສະຫະລັດ ໂດລາ (USD) </option>
                                                    <option value="3">ໄທບາດ (THB)</option>
                                                    <option value="4">ຈີນ ເງິນຢວນ (CNY)</option>
													
	                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group basic">
                                            <div class="input-wrapper">
                                                <label class="label" for="currency2">ເປັນສະກຸນເງີນ</label>
                                                <select class="form-control custom-select" id="currency2">
													<option value="1">ລາວກີບ (LAK)</option>
                                                    <option value="2">ສະຫະລັດ ໂດລາ (USD) </option>
                                                    <option value="3">ໄທບາດ (THB)</option>
                                                    <option value="4">ຈີນ ເງິນຢວນ (CNY)</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group basic">
                                    <label class="label">ຈຳນວນເງິນ</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="input1">₭</span>
                                        </div>
                                        <input type="text" class="form-control form-control-lg" value="100">
                                    </div>
                                </div>



                                <div class="form-group basic">
                                    <button type="button" class="btn btn-primary btn-block btn-lg"
                                        data-dismiss="modal">ສົ່ງແລກປ່ຽນ</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- * Exchange Action Sheet -->

        <!-- Stats -->
        <div class="section">
            <div class="row mt-2">
                <div class="col-6">
                    <div class="stat-box">
                        <div class="title">ລາຍຮັບ</div>
                        <div class="value text-success">₭ 552.95</div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="stat-box">
                        <div class="title">ລາຍຈ່າຍ</div>
                        <div class="value text-danger">₭ 86.45</div>
                    </div>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-6">
                    <div class="stat-box">
                        <div class="title">ລວມບິນ</div>
                        <div class="value">₭ 53.25</div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="stat-box">
                        <div class="title">ເງິນຝາກປະຢັດ</div>
                        <div class="value">₭ 120.99</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- * Stats -->

        <!-- Transactions -->
        <div class="section mt-4">
            <div class="section-heading">
                <h2 class="title">ການເຮັດທຸລະກຳ</h2>
                <a href="#" class="link">ສະແດງໝົດ</a>
            </div>
            <div class="transactions">
                <!-- item -->
                <a href="app-transaction-detail.html" class="item">
                    <div class="detail">
                        <img src="assets/img/sample/brand/1.jpg" alt="img" class="image-block imaged w48">
                        <div>
                            <strong>ແລກປ່ຽນ</strong>
                            <p>ໂອນແລກປ່ຽນເງິນຕາ</p>
                        </div>
                    </div>
                    <div class="right">
                        <div class="price text-danger"> - ₭ 150</div>
                    </div>
                </a>
                <!-- * item -->
                <!-- item -->
                <a href="app-transaction-detail.html" class="item">
                    <div class="detail">
                        <img src="assets/img/sample/brand/2.jpg" alt="img" class="image-block imaged w48">
                        <div>
                            <strong>ໂອນເງິນ</strong>
                            <p>ໂອນແລກປ່ຽນ</p>
                        </div>
                    </div>
                    <div class="right">
                        <div class="price text-danger">- ₭ 29</div>
                    </div>
                </a>
                <!-- * item -->
                <!-- item -->
                <a href="app-transaction-detail.html" class="item">
                    <div class="detail">
                        <img src="assets/img/sample/avatar/avatar3.jpg" alt="img" class="image-block imaged w48">
                        <div>
                            <strong>ໂອນເງິນ</strong>
                            <p>ໂອນມາຮັບເງິນສົດ</p>
                        </div>
                    </div>
                    <div class="right">
                        <div class="price">+ ₭ 1,000</div>
                    </div>
                </a>
                <!-- * item -->
                <!-- item -->
                <a href="app-transaction-detail.html" class="item">
                    <div class="detail">
                        <img src="assets/img/sample/avatar/avatar4.jpg" alt="img" class="image-block imaged w48">
                        <div>
                            <strong>ໂອນເງິນ</strong>
                            <p>ຊຳລະຄ່າໄຟຟ້າ</p>
                        </div>
                    </div>
                    <div class="right">
                        <div class="price text-danger">- ₭ 186</div>
                    </div>
                </a>
                <!-- * item -->
            </div>
        </div>
        <!-- * Transactions -->

        <!-- my cards -->
        <div class="section full mt-4">
            <div class="section-heading padding">
                <h2 class="title">ຂໍ້ມູນບັດ</h2>
                <a href="cards.php" class="link">ສະແດງໝົດ</a>
            </div>
            <div class="carousel-single owl-carousel owl-theme shadowfix">
                <div class="item">
                    <!-- card block -->
                    <div class="card-block bg-primary">
                        <div class="card-main">
                            <div class="card-button dropdown">
                                <button type="button" class="btn btn-link btn-icon" data-toggle="dropdown">
                                    <ion-icon name="ellipsis-horizontal"></ion-icon>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="javacript:;">
                                        <ion-icon name="pencil-outline"></ion-icon>ແກ້ໄຂ
                                    </a>
                                    <a class="dropdown-item" href="javacript:;">
                                        <ion-icon name="close-outline"></ion-icon>ລືບອອກ
                                    </a>
                                    <a class="dropdown-item" href="javacript:;">
                                        <ion-icon name="arrow-up-circle-outline"></ion-icon>ປັບປຸງ
                                    </a>
                                </div>
                            </div>
                            <div class="balance">
                                <span class="label">ຈຳນວນເຫຼືອ</span>
                                <h1 class="title">₭ 1,256,90</h1>
                            </div>
                            <div class="in">
                                <div class="card-number">
                                    <span class="label">ເລກບັນຊີ</span>
                                    •••• 9905
                                </div>
                                <div class="bottom">
                                    <div class="card-expiry">
                                        <span class="label">ວັນໝົດອາຍຸ</span>
                                        12 / 25
                                    </div>
                                    <div class="card-ccv">
                                        <span class="label">ລະຫັດປ້ອງກັນ(CCV)</span>
                                        553
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- * card block -->
                </div>
                <div class="item">
                    <!-- card block -->
                    <div class="card-block bg-dark">
                        <div class="card-main">
                            <div class="card-button dropdown">
                                <button type="button" class="btn btn-link btn-icon" data-toggle="dropdown">
                                    <ion-icon name="ellipsis-horizontal"></ion-icon>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="javacript:;">
                                        <ion-icon name="pencil-outline"></ion-icon>ແກ້ໄຂ
                                    </a>
                                    <a class="dropdown-item" href="javacript:;">
                                        <ion-icon name="close-outline"></ion-icon>ລືບອອກ
                                    </a>
                                    <a class="dropdown-item" href="javacript:;">
                                        <ion-icon name="arrow-up-circle-outline"></ion-icon>ປັບປຸງ
                                    </a>
                                </div>
                            </div>
                            <div class="balance">
                                <span class="label">ຈຳນວນເຫຼືອ</span>
                                <h1 class="title">₭ 1,256,90</h1>
                            </div>
                            <div class="in">
                                <div class="card-number">
                                    <span class="label">ເລກບັນຊີ</span>
                                    •••• 9905
                                </div>
                                <div class="bottom">
                                    <div class="card-expiry">
                                        <span class="label">ວັນໝົດອາຍຸ</span>
                                        12 / 25
                                    </div>
                                    <div class="card-ccv">
                                        <span class="label">ລະຫັດປ້ອງກັນ(CCV)</span>
                                        553
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- * card block -->
                </div>
                <div class="item">
                    <!-- card block -->
                    <div class="card-block bg-secondary">
                        <div class="card-main">
                            <div class="card-button dropdown">
                                <button type="button" class="btn btn-link btn-icon" data-toggle="dropdown">
                                    <ion-icon name="ellipsis-horizontal"></ion-icon>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="javacript:;">
                                        <ion-icon name="pencil-outline"></ion-icon>ແກ້ໄຂ
                                    </a>
                                    <a class="dropdown-item" href="javacript:;">
                                        <ion-icon name="close-outline"></ion-icon>ລືບອອກ
                                    </a>
                                    <a class="dropdown-item" href="javacript:;">
                                        <ion-icon name="arrow-up-circle-outline"></ion-icon>ປັບປຸງ
                                    </a>
                                </div>
                            </div>
                            <div class="balance">
                                <span class="label">ຈຳນວນເຫຼືອ</span>
                                <h1 class="title">₭ 1,256,90</h1>
                            </div>
                            <div class="in">
                                <div class="card-number">
                                    <span class="label">ເງິນເຫຼືອໃນບັນຊີ</span>
                                    •••• 9905
                                </div>
                                <div class="bottom">
                                    <div class="card-expiry">
                                        <span class="label">ວັນໝົດອາຍຸ</span>
                                        12 / 25
                                    </div>
                                    <div class="card-ccv">
                                        <span class="label">ລະຫັດປ້ອງກັນ(CCV)</span>
                                        553
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- * card block -->
                </div>
            </div>
        </div>
        <!-- * my cards -->

        <!-- Send Money -->
        <div class="section full mt-4">
            <div class="section-heading padding">
                <h2 class="title">ໂອນເງິນ</h2>
                <a href="javascript:;" class="link">ເພີ່ມໃໝ່</a>
            </div>
            <div class="shadowfix carousel-small owl-carousel owl-theme">
                <!-- item -->
                <div class="item">
                    <a href="#">
                        <div class="user-card">
                            <img src="assets/img/sample/avatar/avatar2.jpg" alt="img" class="imaged w-48">
                            <strong>ໂອນແລກປ່ຽນ</strong>
                        </div>
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <a href="#">
                        <div class="user-card">
                            <img src="assets/img/sample/avatar/avatar3.jpg" alt="img" class="imaged w-48">
                            <strong>ໂອນມາຮັບເງິນສົດ</strong>
                        </div>
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <a href="#">
                        <div class="user-card">
                            <img src="assets/img/sample/avatar/avatar4.jpg" alt="img" class="imaged w-48">
                            <strong>ໂອນຈ່າຍຄ່າບໍລິການ</strong>
                        </div>
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <a href="#">
                        <div class="user-card">
                            <img src="assets/img/sample/avatar/avatar5.jpg" alt="img" class="imaged w-48">
                            <strong>ຈ່າຍຄ່າໄຟຟ້າ</strong>
                        </div>
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <a href="#">
                        <div class="user-card">
                            <img src="assets/img/sample/avatar/avatar6.jpg" alt="img" class="imaged w-48">
                            <strong>ຈ່າຍຄ່ານ້ຳປະປາ</strong>
                        </div>
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <a href="#">
                        <div class="user-card">
                            <img src="assets/img/sample/avatar/avatar7.jpg" alt="img" class="imaged w-48">
                            <strong>ໂອນໃຫ້ເພື່ອນ</strong>
                        </div>
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <a href="#">
                        <div class="user-card">
                            <img src="assets/img/sample/avatar/avatar8.jpg" alt="img" class="imaged w-48">
                            <strong>ໂອນຊື້ເຄື່ອງອອນລາຍ</strong>
                        </div>
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <a href="#">
                        <div class="user-card">
                            <img src="assets/img/sample/avatar/avatar9.jpg" alt="img" class="imaged w-48">
                            <strong>ໂອນຈ່າຍຄ່າປະກັນໄພ</strong>
                        </div>
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <a href="#">
                        <div class="user-card">
                            <img src="assets/img/sample/avatar/avatar10.jpg" alt="img" class="imaged w-48">
                            <strong>ໂອນມັດຈຳຄ່າເຄື່ອງ</strong>
                        </div>
                    </a>
                </div>
                <!-- * item -->
            </div>
        </div>
        <!-- * Send Money -->

        <!-- Monthly Bills -->
        <div class="section full mt-4">
            <div class="section-heading padding">
                <h2 class="title">ບິນລາຍເດືອນ</h2>
                <a href="#" class="link">ສະແດງໝົດ</a>
            </div>
            <div class="carousel-multiple owl-carousel owl-theme shadowfix">
                <!-- item -->
                <div class="item">
                    <div class="bill-box">
                        <div class="img-wrapper">
                            <img src="assets/img/sample/brand/1.jpg" alt="img" class="image-block imaged w48">
                        </div>
                        <div class="price">₭ 14</div>
                        <p>ແຜນຊຳລະຄ່າງວນສິນເຊືອລາຍເດືອນ</p>
                        <a href="#" class="btn btn-primary btn-block btn-sm">ສັ່ງຈ່າຍ</a>
                    </div>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <div class="bill-box">
                        <div class="img-wrapper">
                            <img src="assets/img/sample/brand/2.jpg" alt="img" class="image-block imaged w48">
                        </div>
                        <div class="price">₭ 9</div>
                        <p>ແຜນຊຳລະຄ່າບໍລິການລາຍເດືອນ</p>
                        <a href="#" class="btn btn-primary btn-block btn-sm">ສັ່ງຈ່າຍ</a>
                    </div>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <div class="bill-box">
                        <div class="img-wrapper">
                            <div class="iconbox bg-danger">
                                <ion-icon name="medkit-outline"></ion-icon>
                            </div>
                        </div>
                        <div class="price">₭ 299</div>
                        <p>ແຜນຊຳລະຄ່າປະກັນສັງຄົມ</p>
                        <a href="#" class="btn btn-primary btn-block btn-sm">ສັ່ງຈ່າຍ</a>
                    </div>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <div class="bill-box">
                        <div class="img-wrapper">
                            <div class="iconbox">
                                <ion-icon name="card-outline"></ion-icon>
                            </div>
                        </div>
                        <div class="price">₭ 962</div>
                        <p>ແຜນຊຳລະຄ່າບໍລິການບັດລາຍເດືອນ
                        </p>
                        <a href="#" class="btn btn-primary btn-block btn-sm">ສົ່ງຈ່າຍ</a>
                    </div>
                </div>
                <!-- * item -->
            </div>
        </div>
        <!-- * Monthly Bills -->


        <!-- Saving Goals -->
        <div class="section mt-4">
            <div class="section-heading">
                <h2 class="title">ບັນຊີປະຢັດສະສົມ</h2>
                <a href="#" class="link">ສະແດງໝົດ</a>
            </div>
            <div class="goals">
                <!-- item -->
                <div class="item">
                    <div class="in">
                        <div>
                            <h4>ເພື່ອການສຶກສາ</h4>
                            <p>ບັນຊີສະສົມເພື່ອການສຶກສາ</p>
                        </div>
                        <div class="price">₭ 499</div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" style="width: 85%;" aria-valuenow="85"
                            aria-valuemin="0" aria-valuemax="100">85%</div>
                    </div>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <div class="in">
                        <div>
                            <h4>ເພື່ອຊື້ບ້ານໃໝ່</h4>
                            <p>ບັນຊີປະຢັດເພື່ອອານາຄົດ</p>
                        </div>
                        <div class="price">₭ 100,000</div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" style="width: 55%;" aria-valuenow="55"
                            aria-valuemin="0" aria-valuemax="100">55%</div>
                    </div>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="item">
                    <div class="in">
                        <div>
                            <h4>ເພື່ອຊື້ລົດ</h4>
                            <p>ບັນຊີປະຢັດເພື່ອຊີວິດ</p>
                        </div>
                        <div class="price">₭ 42,500</div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" style="width: 15%;" aria-valuenow="15"
                            aria-valuemin="0" aria-valuemax="100">15%</div>
                    </div>
                </div>
                <!-- * item -->
            </div>
        </div>
        <!-- * Saving Goals -->


        <!-- News -->
        <div class="section full mt-4 mb-3">
            <div class="section-heading padding">
                <h2 class="title">ຂ່າວຫຼ້າສຸດ</h2>
                <a href="app-blog.html" class="link">ສະແດງໝົດ</a>
            </div>
            <div class="shadowfix carousel-multiple owl-carousel owl-theme">

                <!-- item -->
                <div class="item">
                    <a href="app-blog-post.html">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/11.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ສະຖາບັນການເງິນຊັບທະວີ ບໍລິການແລກປ່ຽນເງິນຕາ...</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- * item -->

                <!-- item -->
                <div class="item">
                    <a href="app-blog-post.html">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/22.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ສະຖາບັນການເງິນຊັບທະວີ ບໍລິການສິນເຊືອ...</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- * item -->

                <!-- item -->
                <div class="item">
                    <a href="app-blog-post.html">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/33.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ສະຖາບັນການເງິນຊັບທະວີ ບໍລິການເສຍຄ່າພາສາອາກອນ...</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- * item -->

                <!-- item -->
                <div class="item">
                    <a href="app-blog-post.html">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/44.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ສະຖາບັນການເງິນຊັບທະວີ ບໍລິການປະກັນໄພ...</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- * item -->

            </div>
        </div>
        <!-- * News -->


        <!-- app footer -->
        <div class="appFooter">
            <div class="footer-title">
                Copyright © smi-service 2020. All Rights Reserved.
            </div>
            ສະຖາບັນການເງິນຊັບທະວີ ສະຫງວນລິຂະສິດ.
        </div>
        <!-- * app footer -->

    </div>
    <!-- * App Capsule -->

  <?php include 'app-menu.php'; ?>	
    <!-- App Sidebar -->
    <div class="modal fade panelbox panelbox-left" id="sidebarPanel" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <!-- profile box -->
                    <div class="profileBox pt-2 pb-2">
                        <div class="image-wrapper">
                            <img src="assets/img/sample/avatar/avatar1.jpg" alt="image" class="imaged  w36">
                        </div>
                        <div class="in">
                            <strong>ຊື່ລູກຄ້າ</strong>
                            <div class="text-muted">58996638</div>
                        </div>
                        <a href="#" class="btn btn-link btn-icon sidebar-close" data-dismiss="modal">
                            <ion-icon name="close-outline"></ion-icon>
                        </a>
                    </div>
                    <!-- * profile box -->
                    <!-- balance -->
                    <div class="sidebar-balance">
                        <div class="listview-title">ເງິນໃນບັນຊີ</div>
                        <div class="in">
                            <h1 class="amount">₭ 2,562.50</h1>
                        </div>
                    </div>
                    <!-- * balance -->

                    <!-- action group -->
                    <div class="action-group">
                        <a href="app-index.html" class="action-button">
                            <div class="in">
                                <div class="iconbox">
                                    <ion-icon name="add-outline"></ion-icon>
                                </div>
                                ຝາກເງິນ
                            </div>
                        </a>
                        <a href="app-index.html" class="action-button">
                            <div class="in">
                                <div class="iconbox">
                                    <ion-icon name="arrow-down-outline"></ion-icon>
                                </div>
                                ຖອນເງິນ
                            </div>
                        </a>
                        <a href="app-index.html" class="action-button">
                            <div class="in">
                                <div class="iconbox">
                                    <ion-icon name="arrow-forward-outline"></ion-icon>
                                </div>
                                ໂອນເງິນ
                            </div>
                        </a>
                        <a href="app-cards.html" class="action-button">
                            <div class="in">
                                <div class="iconbox">
                                    <ion-icon name="card-outline"></ion-icon>
                                </div>
                                ຂໍ້ມູນບັດ
                            </div>
                        </a>
                    </div>
                    <!-- * action group -->

                    <!-- menu -->
                    <div class="listview-title mt-1">ລາຍການ</div>
                    <ul class="listview flush transparent no-line image-listview">
                        <li>
                            <a href="index.php" class="item">
                                <div class="icon-box bg-primary">
                                    <ion-icon name="pie-chart-outline"></ion-icon>
                                </div>
                                <div class="in">
                                    ບໍລິການ
                                    <span class="badge badge-primary">10</span>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="notifications.php" class="item">
                                <div class="icon-box bg-primary">
                                    <ion-icon class="icon" name="notifications-outline"></ion-icon>
                                </div>
                                <div class="in">
                                    ຂໍ້ຄວາມ
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="flog.php" class="item">
                                <div class="icon-box bg-primary">
                                    <ion-icon name="apps-outline"></ion-icon>
                                </div>
                                <div class="in">
                                    ຂ່າວສານ
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="cards.php" class="item">
                                <div class="icon-box bg-primary">
                                    <ion-icon name="card-outline"></ion-icon>
                                </div>
                                <div class="in">
                                    ຂໍ້ມູນບັດ
                                </div>
                            </a>
                        </li>
                    </ul>
                    <!-- * menu -->

                    <!-- others -->
                    <div class="listview-title mt-1">ບໍລິການອື່ນ</div>
                    <ul class="listview flush transparent no-line image-listview">
                        <li>
                            <a href="settings.php" class="item">
                                <div class="icon-box bg-primary">
                                    <ion-icon name="settings-outline"></ion-icon>
                                </div>
                                <div class="in">
                                    ຕັ້ງຄ່າ
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="messages.php" class="item">
                                <div class="icon-box bg-primary">
                                    <ion-icon name="chatbubble-outline"></ion-icon>
                                </div>
                                <div class="in">
                                    ຕິດຕໍ່ສອບຖາມ
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="login.php" class="item">
                                <div class="icon-box bg-primary">
                                    <ion-icon name="log-out-outline"></ion-icon>
                                </div>
                                <div class="in">
                                    ອອກລະບົບ
                                </div>
                            </a>
                        </li>
                    </ul>
                    <!-- * others -->

                    <!-- send money -->
                    <div class="listview-title mt-1">ໂອນເງິນ</div>
                    <ul class="listview image-listview flush transparent no-line">
                        <li>
                            <a href="#" class="item">
                                <img src="assets/img/sample/avatar/avatar2.jpg" alt="image" class="image">
                                <div class="in">
                                    <div>ໂອນເງິນມາແລກປ່ຽນ</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="item">
                                <img src="assets/img/sample/avatar/avatar4.jpg" alt="image" class="image">
                                <div class="in">
                                    <div>ໂອນມາຮັບເງິນສົດ</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="item">
                                <img src="assets/img/sample/avatar/avatar3.jpg" alt="image" class="image">
                                <div class="in">
                                    <div>ໂອນຈ່າຍຄ່າບໍລິການ</div>
                                </div>
                            </a>
                        </li>
                    </ul>
                    <!-- * send money -->

                </div>
            </div>
        </div>
    </div>
   