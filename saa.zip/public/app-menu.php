	  <!-- App Bottom Menu -->
    <div class="appBottomMenu bg-primary text-light">
        <a href="index.php" class="item active">
            <div class="col">
                <ion-icon name="pie-chart-outline"></ion-icon>
                <strong>ບໍລິການ</strong>
            </div>
        </a>
        <a href="notifications.php" class="item">
            <div class="col">      
				 <ion-icon class="icon" name="notifications-outline"></ion-icon>
                <strong>ຂໍ້ຄວາມ</strong>
            </div>
        </a>
        <a href="blog.php" class="item">
            <div class="col">
                <ion-icon name="apps-outline"></ion-icon>
                <strong>ຂ່າວສານ</strong>
            </div>
        </a>
        <a href="cards.php" class="item">
            <div class="col">
                <ion-icon name="card-outline"></ion-icon>
                <strong>ຂໍ້ມູນບັດ</strong>
            </div>
        </a>
        <a href="settings.php" class="item">
            <div class="col">
                <ion-icon name="settings-outline"></ion-icon>
                <strong>ຕັ້ງຄ່າ</strong>
            </div>
        </a>
    </div>	
    <!-- * App Bottom Menu -->	
