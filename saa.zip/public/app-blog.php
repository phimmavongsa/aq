    <!-- App Header -->
    <div class="appHeader bg-primary text-light">
	  <div class="left">
            <a href="javascript:;" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">
         ຂ່າວສານ
        </div>
        <div class="bg-primary text-light right">
            <a href="javascript:;" class="headerButton bg-primary toggle-searchbox">
                <ion-icon name="search-outline"></ion-icon>
            </a>
        </div>
    </div>
    <!-- * App Header -->

    <!-- Search Component -->
    <div id="search" class="appHeader">
        <form class="search-form">
            <div class="form-group searchbox">
                <input type="text" class="form-control" placeholder="ຄົ້ນຫາ...">
                <i class="input-icon icon ion-ios-search"></i>
                <a href="javascript:;" class="ml-1 close toggle-searchbox"><i class="icon ion-ios-close-circle"></i></a>
            </div>
        </form>
    </div>
    <!-- * Search Component -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="section tab-content mt-2 mb-2">

            <div class="row">
                <div class="col-6 mb-2">
                    <a href="blog-post.php">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/11.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ບໍລິການທຸລະກຳດ້ານການເງິນ</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-6 mb-2">
                    <a href="blog-post.php">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/22.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ສິນເຊື່ອເງິນດ່ວນ</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-6 mb-2">
                    <a href="blog-post.php">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/33.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ບໍລິການຖອນເງິນສົດ EDC</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-6 mb-2">
                    <a href="blog-post.php">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/44.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ບໍລິການຊຳລະຄ່າໄຟຟ້າ, ນ້ຳປະປາ</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-6 mb-2">
                    <a href="blog-post.php">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/55.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ສິນເຊື່ອເພື່ອພະນັກງານ</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-6 mb-2">
                    <a href="blog-post.php">
                        <div class="blog-card">
                            <img src="assets/img/news/photo/66.jpg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">ບໍລິການເສຍຄ່າທຳນຽມທາງ</h4>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

            <div>
                <a href="javascript:;" class="btn btn-block btn-primary btn-lg">ສະແດງເພີ່ມ</a>
            </div>

        </div>

    </div>
    <!-- * App Capsule -->
