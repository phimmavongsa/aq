 <!-- loader -->
    <div id="loader">
        <img src="assets/img/logo-icon.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

   <!-- App Header -->
    <div class="appHeader  bg-primary text-light no-border transparent position-absolute">
        <div class="left">
            <a href="javascript:;" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle"></div>
        <div class="right">
        </div>
		 <div class="pageTitle">
			<label style="font-size:24px;" class="label" for="photo">&nbsp;ຢືນຢັນລະຫັດໃໝ່ຜ່ານຂໍ້ຄວາມ</label>
        </div> 
    </div>
    <!-- * App Header -->
    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="section mt-2 text-center">
             <h1>ຢືນຢັນລະຫັດຜ່ານຂໍ້ຄວາມ</h1>
            <h4>ປ້ອນຕົວເລກ 4 ໂຕ ຜ່ານຂໍ້ຄວາມ ເພື່ອຢືນຢັນລະຫັດ</h4>
        </div>
        <div class="section mb-5 p-2">
            <form action="login.php">
                <div class="form-group basic">
                    <input type="text" class="form-control verification-input" id="smscode" placeholder="••••"
                        maxlength="4">
                </div>

                <div class="form-button-group transparent">
                    <button type="submit" class="btn btn-primary btn-block btn-lg">ຢືນຢັນ</button>
                </div>

            </form>
        </div>

    </div>
    <!-- * App Capsule -->
