
<?php 
include 'includes/config.php'; 
  ob_start(); 
    session_start();
if(isset($_GET['txtKeyword'])){
	$txtKeyword=$_GET['txtKeyword'];
}else{
	$txtKeyword="";
}
	if(!isset($_SESSION['lng'])){
		 $_SESSION['lng']="la";
	}else{
		
		if(isset($_GET['lng'])) {
			$_SESSION['lng']=$_GET['lng'];
		}else{
			$_SESSION['lng']=$_SESSION['lng'];
			
		}
	}
?>
<!DOCTYPE html>
<html lang="la">
<head>
    <meta charset="UTF-8" />
    <title>Guangzhou Cargo Laos</title>
    <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
	
	<meta name="robots" content="noindex, nofollow">
	<link rel="stylesheet" href="css/track-status.css">
	<link rel="stylesheet" href="css/track.css">
	<link rel="stylesheet" href="css/ionicons.min.css">
	<link rel="stylesheet" href="css/featherlight.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">

<!-- <link rel="manifest" href="../img/favicon/manifest.json"> -->
	<link rel="stylesheet" href="./search_files/main.css">
	<script src="./search_files/jquery.js.download"></script>
	<meta name="viewport" content="width=device-width, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
	<link href="./search_files/css" rel="stylesheet" type="text/css">
	<script src="./search_files/featherlight.min.js.download"></script>	
	
    <link rel="apple-touch-icon" sizes="57x57" href="img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x321.png"> 
    <link rel="icon" type="image/png" sizes="96x96" href="img/favicon/favicon-96x961.png"> 
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x161.png"> 
    <link rel="manifest" href="img/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/timeline.mini.css">
    <link rel="stylesheet" href="css/responsive.css">
	<script src="js1/jquery.js"></script>
        <script src="js1/timeline.min.js"></script>
        <link rel="stylesheet" href="css1/timeline.min.css" />

	<style type="text/css">
    @import url("LAOS/stylesheet.css");
		body,td,th ,h3{
			font-family: LAOS;
		}

		 @import url("LAOS/stylesheet.css");
		.save{
			font-family: LAOS;
		}
	</style>
	<style type="text/css">
		.auto-style1 {
			font-family: LAOS;
		}
	</style>
</head>
<body class="active-preloader-ovh">
<link href="./search_files/all.css" rel="stylesheet">
<section class="inner-banner gray-bg text-center">
	<div class="thm-container">	
		<h3>ຕິດຕາມການຂົນສົ່ງເຄື່ອງຂອງທ່ານ ໄດ້ທຸກເວລາ</h3>
	</div><!-- /.thm-container -->
<!-- /.inner-banner -->
<div class="thm-container">
	<form name="frmSearch" method="get" action="search.php">
	<input type="hidden" id="ljjCMrm" name="track">
	<div class="box">
        <h3 align="center">Track &amp; Trace</h1>
        <div class="txt" align="center">ຕິດຕາມການຂົນສົ່ງເຄື່ອງຂອງທ່ານ ໄດ້ທຸກເວລາ</div>
		<div class="col-sm-10">
        <div class="form-group form-float"> 
          <div class="form-line">
		  <input name="txtKeyword" type="text" class="form-control" id="txtKeyword" value="<?php echo $txtKeyword;?>" required></div> 
        </div></div>
    </div>
   <div>
	<div class="col-sm-1">
	<button type="submit" name="btnSearch" class="btn bg-blue btn-circle waves-effect waves-circle waves-float">
	<i class="material-icons">search</i></i></button>
	</div>
	</div>
</form>
 </div>
</section>
		
	<div class="thm-container">	
	<!--	<h3>ສະຖານະການຂົນສົ່ງ</h3>  -->
	</div><!-- /.thm-container -->
        
  <!--  </div> /.thm-container -->
<!-- /.contact-page-wrapper -->
<?php// include 'public/timeline.php'; ?>
<?php// include 'public/footer-top.php'; ?>
<?php// include 'public/footer-bottom.php'; ?>
<?php //include 'public/scroll-to-top.php'; ?>

</body>
</html>