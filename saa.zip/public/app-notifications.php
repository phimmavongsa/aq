
    <!-- App Header -->
    <div class="appHeader bg-primary text-light">
        <div class="left">
            <a href="#" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">
            ຂໍ້ຄວາມ
        </div>
        <div class="right">
            <a href="javascript:;" class="headerButton">
                <ion-icon name="add-outline"></ion-icon>
            </a>
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="section full">

            <ul class="listview image-listview flush">
                <li class="active">
                    <a href="notification-detail.php" class="item">
                        <div class="icon-box bg-primary">
                            <ion-icon name="arrow-down-outline"></ion-icon>
                        </div>
                        <div class="in">
                            <div>
                                <div class="mb-05"><strong>ໄດ້​ຮັບ​ການ​ຊໍາ​ລະ​ເງິນ</strong></div>
                                <div class="text-small mb-05">ທ່ານ ສີໝອນ ໄດ້ສົ່ງເງິນໃຫ້ເຈົ້າ  <b>₭ 50</b></div>
                                <div class="text-xsmall">5/3/2020 10:30 AM</div>
                            </div>
                            <span class="badge badge-primary badge-empty"></span>
                        </div>
                    </a>
                </li>
                <li class="active">
                    <a href="notification-detail.php" class="item">
                        <div class="icon-box bg-success">
                            <ion-icon name="arrow-forward-outline"></ion-icon>
                        </div>
                        <div class="in">
                            <div>
                                <div class="mb-05"><strong>ການໂອນເງິນໄດ້ສຳເລັດ</strong></div>
                                <div class="text-small mb-05">ການໂອນເງິນຂອງທ່ານໄດ້ສຳເລັດ.</div>
                                <div class="text-xsmall">5/3/2020 10:30 AM</div>
                            </div>
                            <span class="badge badge-primary">3</span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="notification-detail.php" class="item">
                        <div class="icon-box bg-danger">
                            <ion-icon name="key-outline"></ion-icon>
                        </div>
                        <div class="in">
                            <div>
                                <div class="mb-05"><strong>ໄດ້ປ່ຽນລະຫັດຜ່ານສຳເລັດ</strong></div>
                                <div class="text-small mb-05">ລະຫັດຜ່ານຂອງທ່ານໄດ້ຖືກປ່ຽນສຳເລັດ</div>
                                <div class="text-xsmall">5/3/2020 10:30 AM</div>
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="notification-detail.php" class="item">
                        <div class="icon-box bg-warning">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </div>
                        <div class="in">
                            <div>
                                <div class="mb-05"><strong>ໄດ້ຮັບຂໍ້ຄວາມໃໝ່</strong></div>
                                <div class="text-small mb-05">ທ່່ານໄດ້ຮັບຂໍ້ຄວາມໃໝ່ຈາກເພຶ່ອ</div>
                                <div class="text-xsmall">5/3/2020 10:30 AM</div>
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="notification-detail.php" class="item">
                        <div class="icon-box bg-primary">
                            <ion-icon name="arrow-down-outline"></ion-icon>
                        </div>
                        <div class="in">
                            <div>
                                <div class="mb-05"><strong>ການຊຳລະເງິນສຳເລັດ</strong></div>
                                <div class="text-small mb-05">ທ່ານໄດ້ໂອນເງີນຊຳລະສຳເລັດ <b>₭ 50</b></div>
                                <div class="text-xsmall">5/3/2020 10:30 AM</div>
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="notification-detail.php" class="item">
                        <div class="icon-box bg-success">
                            <ion-icon name="arrow-forward-outline"></ion-icon>
                        </div>
                        <div class="in">
                            <div>
                                <div class="mb-05"><strong>ການໂອນເງິນສຳເລັດ</strong></div>
                                <div class="text-small mb-05">ທ່ານໄດ້ໂອນເງິນໃຫ້ເພື່ອສຳເລັດ.</div>
                                <div class="text-xsmall">5/3/2020 10:30 AM</div>
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="notification-detail.php" class="item">
                        <div class="icon-box bg-danger">
                            <ion-icon name="key-outline"></ion-icon>
                        </div>
                        <div class="in">
                            <div>
                                <div class="mb-05"><strong>ປ່ຽນລະຫັດຜ່ານສຳເລັດ</strong></div>
                                <div class="text-small mb-05">ທ່ານໄດ້ປ່ຽນລະຫັດສຳເລັດ</div>
                                <div class="text-xsmall">5/3/2020 10:30 AM</div>
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="notification-detail.php" class="item">
                        <div class="icon-box bg-warning">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </div>
                        <div class="in">
                            <div>
                                <div class="mb-05"><strong>ທ່ານໄດ້ຮັບຂໍ້ຄວາມໃໝ່</strong></div>
                                <div class="text-small mb-05">ທ່ານໄດ້ຮັບຂໍ້ຄວາມໃໝ່</div>
                                <div class="text-xsmall">5/3/2020 10:30 AM</div>
                            </div>
                        </div>
                    </a>
                </li>
            </ul>

        </div>

    </div>
    <!-- * App Capsule -->

