
    <!-- App Capsule -->
    <div id="appCapsule">
        <div class="section mt-2 text-center">
            <h1>ລົງທະບຽນ</h1>
        </div>
        <div class="section mb-5 p-2">
            <form action="register-profile.php" method="POST" enctype="multipart/form-data">
                <div class="card">
                    <div class="card-body">
						<div class="form-group basic">
                            <div class="input-wrapper">								
                                <label style="font-size:12px;" class="label" for="photo">ຮູບຂອງທ່ານ(*)</label>
								<input type="file" id="mypic" accept="image/*" capture="environment" style="font-size:14px;" required>
								<br>
								<canvas id="canvas" width="82" height="82" style="border:1px solid #d3d3d3;">									
							  <script>
								  var input = document.querySelector('input[type=file]'); // see Example 4
								  input.onchange = function () {
									var file = input.files[0];
									//upload(file);
									drawOnCanvas(file);   // see Example 6
									//displayAsImage(file); // see Example 7
								  };
								 
								  function upload(file) {
									var form = new FormData(),
										xhr = new XMLHttpRequest();
								 
									form.append('image', file);
									xhr.open('post', 'server.php', true);
									xhr.send(form);
								  }
								 
								  function drawOnCanvas(file) {
									var reader = new FileReader();
									reader.onload = function (e) {
									  var dataURL = e.target.result,
										  c = document.querySelector('canvas'), // see Example 4
										  ctx = c.getContext('2d'),
										  img = new Image();
								 
									  img.onload = function() {
										c.width = 82;
										c.height = 82;
										ctx.drawImage(img, 0, 0, 82, 82);
									  };
								 
									  img.src = dataURL;
									};
								 
									reader.readAsDataURL(file);
								  }
								 
								  function displayAsImage(file) {
									var imgURL = URL.createObjectURL(file),
										img = document.createElement('img');
								 
									img.onload = function() {
									  URL.revokeObjectURL(imgURL);
									};
								 
									img.src = imgURL;
									document.body.appendChild(img);
								  }
							</script>	
                            </div>
                        </div>     
						
						<div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label" for="email1">ເລກບັັດປະຈຳຕົວ</label>
								<input type="tel" class="form-control" id="idcard" name="idcard"  placeholder="ເລກປັດປະຈຳຕົວ">
                                <i class="clear-input">
                                    <ion-icon name="close-circle"></ion-icon>
                                </i>								
                            </div>
                        </div>					  
						
                        <div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label" for="password1">ສຳມະໂນຄົວ</label>
                                <input name="password" id="password" type="password" class="form-control" placeholder="ເລກສຳມະໂນຄົວ"  >
                                <i class="clear-input">
                                    <ion-icon name="close-circle"></ion-icon>
                                </i>
                            </div>
                        </div>
        
                        <div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label" for="password2">ບັດຜ່ານແດນ</label>
                                <input type="password" name="confirm_password" id="confirm_password" class="form-control"  placeholder="ເລກບັດຜ່່ານແດນ">
                                <i class="clear-input">
                                    <ion-icon name="close-circle"></ion-icon>
                                </i>
								 <span id='message'></span>
                            </div>
                        </div>
						
                    </div>
					
                </div>

		<div class="form-button-group transparent">
                    <button type="submit" class="btn-primary btn-block btn-lg">ຕໍ່ໄປ</button>
		        </div>

            </form>
        </div>

    </div>
    <!-- * App Capsule -->
