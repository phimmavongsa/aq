
    <!-- App Capsule -->
	<script type="text/javascript">
			var check = function() {
			  if (document.getElementById('password').value ==
				document.getElementById('confirm_password').value) {
				document.getElementById('message').style.color = 'green';
				document.getElementById('message').innerHTML = 'ລະຫັດຖືກຕ້ອງ';
			  } else {
				document.getElementById('message').style.color = 'red';
				document.getElementById('message').innerHTML = 'ລະຫັດບໍ່ກົງກັນ';
			  }
			}
		</script>
    <div id="appCapsule">

        <div class="section mt-2 text-center">
            <h1>ລົງທະບຽນ</h1>
        </div>
        <div class="section mb-5 p-2">
            <form action="sms-verification.php" method="POST" enctype="multipart/form-data">
                <div class="card">
                    <div class="card-body">
					    <div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label" for="email1">ເບີໂທລະສັບຂອງທ່ານ</label>
								<input type="tel" class="form-control" id="phone" name="phone" pattern="[0-9]{2}[0-9]{8}" placeholder="20-XXXXXXXX">
                                <i class="clear-input">
                                    <ion-icon name="close-circle"></ion-icon>
                                </i>
                            </div>
                        </div>					  
						
                        <div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label" for="password1">ລະຫັດຜ່ານ</label>
                                <input name="password" id="password" type="password" class="form-control" placeholder="ລະຫັດຜ່ານ" onkeyup='check();' required>
                                <i class="clear-input">
                                    <ion-icon name="close-circle"></ion-icon>
                                </i>
                            </div>
                        </div>
        
                        <div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label" for="password2">ຢືນຢັນລະຫັດຜ່ານ</label>
                                <input type="password" name="confirm_password" id="confirm_password" class="form-control"  placeholder="ຢືນຢັນລະຫັດ" onkeyup='check();' required>
                                <i class="clear-input">
                                    <ion-icon name="close-circle"></ion-icon>
                                </i>
								 <span id='message'></span>
                            </div>
                        </div>

                        <div class="custom-control custom-checkbox mt-2 mb-1">
                            <input type="checkbox" class="custom-control-input" id="customChecka1">
                            <label class="custom-control-label" for="customChecka1">
                                ເຫັນດີ <a href="#" data-toggle="modal" data-target="#termsModal">ຂ້ອຍຍອມຮັບເງື່ອນໄຂ</a>
                            </label>
                        </div>
        
                    </div>
                </div>

				<div class="form-button-group transparent">
                    <button type="submit" class="btn-primary btn-block btn-lg">ຕໍ່ໄປ</button>
		        </div>

            </form>
        </div>

    </div>
    <!-- * App Capsule -->


    <!-- Terms Modal -->
    <div class="modal fade modalbox" id="termsModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">ເງື່ອນໄຂການນຳໃຊ້ SMI-Mobile</h5>
                    <a href="javascript:;" data-dismiss="modal">ປິດ</a>
                </div>
                <div class="modal-body">
                    <p>
                        SMI-Mobile ແມ່ນຜະລິດຕະພັນໜື່ງອອກໂດຍ ສະຖາບັນການເງິນ ຊັບທະວີ (ສຈຊ) ເຊິ່ງເປັນຜະລິດຕະພັນທີ່ສ້າງຄວາມສະດວກ ໃນການໃຫ້ບໍລິການ
						ທຸລະກຳດ້ານການເງິນ ແລະ ສາມາດກວດກາຂໍ້ມູນການເຄື່ອນໄຫວຂອງຕົນຮ່ວມກັບສະຖາບັນໄດ້. ລຸກຄ້າຕ້ອງການນຳໃຊ້ຜະລິດຕະພັນ SMI-Mobile
						ຕ້ອງປະຕິບັດຕາມເງື່ອນໄຂດັ່ງນີ້:					
                    </p>
					<p><b><span>ສະຖາບັນ</span></b></p>
                    <p>
                       ສຈຊ ຈະບໍ່ຮັບຜິດຊອບຕໍ່ຜົນເສຍຫາຍໃດໆ ທີ່ເກີດຂື້ນຈາກການຈຳໃຊ້ SMI-Mobile ດັ່ງຕໍ່ໄປນີ້:
					   ຊື່ນຳໃຊ້ ແລະ ລະຫັດຜ່ານຕ້ອງເປັນຄວາມລັບຫ້າມເປີດເຜີຍ.
						
                    </p>
					<p><b> <span>ຜູ້ນຳໃຊ້ SMI-Mobile</span></b></p>
                    <p>
                       ຜູ້ທີ່ຕ້ອງການນຳໃຊ້ SMI-Mobile ຕ້ອງໄດ້ລົງທະບຽນຖືກຕ້ອງ ກັບ ສຈຊ ຕາມເງື່ອນໄຂຕ່າງໆ							
                    </p>
						<p><b><span>ຂໍ້ມູນສຳລັບການລົງທະບຽນ</span></b></p>
                    <p>
                        ສຳເນົາບັດປະຈຳຕົວ, ສຳມະໂນຄົວ, ໜັງສືຜ່ານແດນ<br>
						ຕ້ອງມີ Email ເປັນຂອງຕົນເອງ<br>
						ເບີໂທລະສັບມືຖື
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- * Terms Modal -->
