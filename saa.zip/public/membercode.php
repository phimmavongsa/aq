
<?php
echo(rand() . "<br>");
echo(rand() . "<br>");
echo(rand(10000,999999));
?>
