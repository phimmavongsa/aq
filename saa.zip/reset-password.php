<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SMI - Mobile</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="Finapp HTML Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, cordova, phonegap, mobile, html, responsive" />
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="shortcut icon" href="assets/img/favicon.png">
	<style type="text/css">
			@import url("LAOS/stylesheet.css");
			body,td,th ,h3{
				font-family: LAOS;
			}

			 @import url("LAOS/stylesheet.css");
			.save{
				font-family: LAOS;
			}
		</style>
		<style type="text/css">
			.auto-style1 {
				font-family: LAOS;
			}
		</style>
</head>

<body>
<?php include 'public/app-reset-password.php'; ?>
<?php include 'public/app-jsfooter.php'; ?>
</body>

</html>