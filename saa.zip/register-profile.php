<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SMI - Mobile</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="SMI Mobile App">
    <meta name="keywords" content="SMI Mobile App Service" />
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="shortcut icon" href="assets/img/favicon.png">
		<style type="text/css">
			@import url("LAOS/stylesheet.css");
			body,td,th ,h3{
				font-family: LAOS;
			}

			 @import url("LAOS/stylesheet.css");
			.save{
				font-family: LAOS;
			}
		</style>
		<style type="text/css">
			.auto-style1 {
				font-family: LAOS;
			}
		</style>
</head>

<body>

<?php include 'public/app-load.php'; ?>
<?php include 'public/app-header.php'; ?>
<?php include 'public/app-register-profile.php'; ?>
    <!-- App Bottom Menu -->
    <div class="appBottomMenu bg-primary text-light">
        <a href="register.php" class="item active">
            <div class="col">
                <ion-icon name="person-add-outline"></ion-icon>
                <strong>ລົງທະບຽນ</strong>
            </div>
        </a>
        <a href="login.php" class="item">
            <div class="col">
             <ion-icon name="log-in-outline"></ion-icon>
                <strong>ເຂົ້າລະບົບ</strong>
            </div>
        </a>
        <a href="service.php" class="item">
            <div class="col">
              <ion-icon name="list-circle-outline"></ion-icon>
                <strong>ບໍລິການ</strong>
            </div>
        </a>	
        <a href="blog.php" class="item">
            <div class="col">
              <ion-icon name="ellipsis-vertical-outline"></ion-icon>
                <strong>ຂ່າວສານ</strong>
            </div>
        </a> 	       
    </div>	
    <!-- * App Bottom Menu -->	
<?php include 'public/app-jsfooter.php'; ?>

</body>

</html>