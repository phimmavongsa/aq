<?php
include 'includes/config.php'; 
if(isset($_GET['txtKeyword'])){
	$txtKeyword=$_GET['txtKeyword'];
}else{
	$txtKeyword="";
	
}
   ob_start(); 
    session_start();
				
	if(!isset($_SESSION['lng'])){
		 $_SESSION['lng']="la";
	}else{
		
		if(isset($_GET['lng'])) {
			$_SESSION['lng']=$_GET['lng'];
		}else{
			$_SESSION['lng']=$_SESSION['lng'];
			
		}
		
	}
?>

<html><head>
    <meta charset="UTF-8" />
    <title>Laos Golbal</title>
    <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
	
	<meta name="robots" content="noindex, nofollow">
	<link rel="stylesheet" href="css/track-status.css">
	<link rel="stylesheet" href="css/track.css">
	<link rel="stylesheet" href="css/ionicons.min.css">
	<link rel="stylesheet" href="css/featherlight.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">

<!-- <link rel="manifest" href="../img/favicon/manifest.json"> -->
	<link rel="stylesheet" href="./search_files/main.css">
	<script src="./search_files/jquery.js.download"></script>
	<link href="./search_files/css" rel="stylesheet" type="text/css">
	<script src="./search_files/featherlight.min.js.download"></script>	
	
    <link rel="apple-touch-icon" sizes="57x57" href="img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x321.png"> 
    <link rel="icon" type="image/png" sizes="96x96" href="img/favicon/favicon-96x961.png"> 
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x161.png"> 
    <link rel="manifest" href="img/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/timeline.mini.css">
    <link rel="stylesheet" href="css/responsive.css">
	<script src="js1/jquery.js"></script>
        <script src="js1/timeline.min.js"></script>
        <link rel="stylesheet" href="css1/timeline.min.css" />

	<style type="text/css">
    @import url("LAOS/stylesheet.css");
		body,td,th ,h3{
			font-family: LAOS;
		}

		 @import url("LAOS/stylesheet.css");
		.save{
			font-family: LAOS;
		}
	</style>
	<style type="text/css">
		.auto-style1 {
			font-family: LAOS;
		}
	</style>
<!-- <link rel="manifest" href="../img/favicon/manifest.json"> -->

<meta name="viewport" content="width=device-width, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<link href="./search_files/css" rel="stylesheet" type="text/css">
<style>

</style>	<script src="./search_files/featherlight.min.js.download"></script>

<body> 
<?php
include'public/headtop.php';
include'public/head.php';
?>

<!--End of  Chatbotuat Script-->
 
<div class="thm-container">
	<form name="frmSearch" method="get" action="search.php">
	<input type="hidden" id="ljjCMrm" name="track">
	<div class="box">
        <h3 align="center">Track &amp; Trace</h1>
        <div class="txt" align="center">ຕິດຕາມການຂົນສົ່ງເຄື່ອງຂອງທ່ານ ໄດ້ທຸກເວລາ</div>
		<div class="col-sm-10">
        <div class="form-group form-float"> 
          <div class="form-line">
		  <input name="txtKeyword" type="text" class="form-control" id="txtKeyword" value="<?php echo $txtKeyword;?>"></div> 
        </div></div>
    </div>
   <div>
	<div class="col-sm-2">
	<button type="submit" name="btnSearch" class="btn bg-blue btn-circle waves-effect waves-circle waves-float">
	<i class="material-icons">search</i></i></button>
	</div>
	</div>
	
</form>

 </div>

</form>
    <div class="sector-frame" style="background-color:#f3f3f4;">
    	<div class="warpper" id="trackAreaNjEw">
        <div class="hidden-image">
            <img src=""></div>
			<div class="sector-frame">
        <div class="warpper">
            <div class="section-status">
                <div class="warpper">
                    <div class="row">
					<?php
					if($txtKeyword != "")
						{
					//	$strSQL = "SELECT id, Tracking_id, tracking_date, refername, reciepname, sendname, status, tracking_reciep, tracking_date, remark FROM tbl_order WHERE Tracking_id LIKE '%".$txtKeyword."%'";
						$strSQL = "SELECT tbl_order.*, tbl_order_detail.* FROM tbl_order, tbl_order_detail where tbl_order.Tracking_id LIKE '%".$txtKeyword."%' LIMIT 1";
						
						$objQuery=mysqli_query($connect,$strSQL);
						$rowcount=mysqli_num_rows($objQuery);
						if ($rowcount<=0) {
							
							echo"No Record";
						}
						?>
						<?php
						while($objResult = mysqli_fetch_array($objQuery))
						{
						?>
                        <div class="col">
                            <div class="info">
                                    <div class="line">ລະຫັດເຄື່ອງ: <span><?php echo $objResult["Tracking_id"];?></span></div>
                                    <div class="line">ຄາດການເວລາ: <span>
									<?php 
									$date=date_create($objResult["tracking_date"]);
									echo date_format($date,"Y/m/d ");
									?></span></div>
									
                                    <div class="line">ອ່າງອີ້ງ: <span><?php echo $objResult["refername"];?></span></div>
                                    <div class="line">ຜູ້ສົ່ງ: <span><?php echo $objResult["sendname"];?></span></div>
                                    <div class="line">ຜູ້ຮັບ: <span><?php echo $objResult["reciepname"];?></span></div>
                                <div class="line">
                               <!--   <img src="img/a.jpg" style="padding-top:20px; width: 90%;">  -->
								 </div>
                            </div>

                            <div class="kerry">
                                 <div class="logo"><h4><img src="img/logos.png">	Guangzhou Cargo Laos Ltd.</h4></div>
                                <div class="txt">
                                    <div class="t1"></div>
                                    <div class="t2"><br></div>
                                </div>
                            </div>
                        </div>
						<?php
							}				
						?>
					   <div class="col colStatus">
					  <?php 
						$strSQL1 = "SELECT tbl_order.*, tbl_order_detail.* FROM tbl_order, tbl_order_detail where tbl_order.Tracking_id LIKE '%".$txtKeyword."%' && tbl_order.numID = tbl_order_detail.numID ORDER BY tbl_order_detail.id DESC";
					    // $strSQL1 = "SELECT * FROM tbl_order_detail WHERE numID LIKE '%".$txtKeyword."%'";
						$objQuery1=mysqli_query($connect,$strSQL1);
						?>
						<?php
						while($objResult1 = mysqli_fetch_array($objQuery1))
						{
						?>
						<?php if ($objResult1["tracking_yes_no"]==1){?>
						          <div class="status piority-success">
                                        <div class="date"><span>ວັນທີ່:</span><?php 
											$date=date_create($objResult1["tracking_date"]);
											echo date_format($date,"Y/m/d ");?>
                                         <div><span>ເວລາ:</span><?php 
											$date=date_create($objResult1["tracking_date"]);
											echo date_format($date,"H:i");?></div>
                                        </div>
                                        <div class="desc">
                                            <div class="d1">
                                                <?php echo $objResult1["Tracking_status"];?>
                                             </div>
											 <div class="d2">
                                                <?php echo $objResult1["tracking_reciep"];?>
                                             </div>
                                            <div class="d2"><?php echo $objResult1["tracking_address"];?> <br></div>
                                        </div>
                                        <div class="icon">
                                            <div class="img">
											<img src="img/yes.png" style="padding-top:0px; width: 50px;">
											</div>
                                        </div>
                                    </div>
						<?php }?>
					  	<?php if ($objResult1["tracking_yes_no"]==0){?>
                                    <div class="status normaly-waiting">
                                       <div class="date"><span>ວັນທີ່:</span><?php 
										$date=date_create($objResult1["tracking_date"]);
									    echo date_format($date,"Y/m/d");?>
                                         <div><span>ເວລາ:</span><?php 
										$date=date_create($objResult1["tracking_date"]);
									    echo date_format($date,"H:i");?></div>
                                        </div>

                                        <div class="desc">
                                            <div class="d1">
                                                <?php echo $objResult1["Tracking_status"];?>
                                             </div>
											 <div class="d2">
                                                <?php echo $objResult1["tracking_reciep"];?>
                                             </div>
                                            <div class="d2"><?php echo $objResult1["tracking_address"];?> <br></div>
                                        </div>
                                        <div class="icon">
                                            <div class="img">
											<img src="img/no.png" style="padding-top:0px; width: 50px;">
											</div>
                                        </div>
                                    </div>	
						     <?php }?>	
                            <?php
							}				
						   ?>
                           
							 </div>
						<?php
							}				
						?>

                    </div>
                </div>
            </div>
        </div>
	<!--	<div class="col-sm-10">ບໍ່ມີລາຍການຂໍ້ມູນ.</div> -->
    </div>
    
<?php include 'public/footer-top.php'; ?>
<?php include 'public/footer-bottom.php'; ?>
<?php include 'public/scroll-to-top.php'; ?>
