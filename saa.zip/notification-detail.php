<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SMI - Mobile</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="SMI Mobile App">
    <meta name="keywords" content="SMI Mobile App Service" />
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="shortcut icon" href="assets/img/favicon.png">
		<style type="text/css">
			@import url("LAOS/stylesheet.css");
			body,td,th ,h3{
				font-family: LAOS;
			}

			 @import url("LAOS/stylesheet.css");
			.save{
				font-family: LAOS;
			}
		</style>
		<style type="text/css">
			.auto-style1 {
				font-family: LAOS;
			}
		</style>
</head>

<body class="bg-white">

<?php include 'public/app-load.php'; ?>
<?php include 'public/app-notification-detail.php'; ?>
<?php include 'public/app-menu.php'; ?>	
<?php include 'public/app-jsfooter.php'; ?>

</body>

</html>